Note
----

I am not 100% sure about the legality of distributing System40.exe and related
DLLs here, so I've left them out. They can be found in the System 4 SDK, which
which you'll want to have anyways to compile these tests.

Once you've copied the files, this directory should contain the following:

    Etc/DLL/Math.dll (not included)
    Etc/HLL/Math.hll
    Etc/Etc.inc
    Etc/SACT_DLL.inc
    System42/DLL/Sys42VM.dll (not included)
    System42/System40.exe (not included)
    System42/System40.ini
    System42/System42.inc
    System.inc
